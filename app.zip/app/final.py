# coding=utf-8
from http.server import HTTPServer, BaseHTTPRequestHandler
import os
import json
import requests
import datetime


# Обработка запросов
class ServiceHandler(BaseHTTPRequestHandler):
    # Устанавливаем параметры заголовков для ответа
    def set_headers(self):
        self.send_response(200)
        self.send_header("Content-type", "text/json")
        length = int(self.headers["Content-Length"])
        content = self.rfile.read(length)
        temp = str(content).strip('b\'')
        self.end_headers()
        return temp

    # При обработке GET-запроса проверяем Ping на 20 хостов
    def do_GET(self):
        temp = self.set_headers()
        self.send_response(200)
        self.send_header("Content-type", "text/json")
        self.end_headers()
        ip_parts = temp.split('.')
        network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
        time1 = datetime.datetime.now()
        for ip in range(int(ip_parts[3]), int(ip_parts[3])+20):
            ip_addr = network_ip + str(ip)
            print(ip_addr)
#           response = os.popen(f'ping -n 1 {ip_addr}') Для работы в Windows среде
            response = os.popen(f'ping -c 1 {ip_addr}')
            res = response.readlines()
            for line in res:
                if (line.count("ttl")) or (line.count("TTL")):# ttl for Linux or TTL for Windows
                    self.wfile.write(("\n" + ip_addr + " -- LIVE\n").encode())
        time2 = datetime.datetime.now()
        totaltime = time2 - time1
        self.wfile.write((f"Complite in {totaltime}").encode())


    # При обработке POST-запроса отрабатывает http-proxy
    def do_POST(self):
        temp = self.set_headers()
        self.send_response(200)
        self.send_header("Content-type", "text/json")
        self.end_headers()
        method = ''
        headers = json
        payloads = ''
        url = ''
        payload = json.loads(temp)
        for key in payload:
            if key == "method":
                method = payload[key]
            if key == "Content-type":
                headers = json.loads("{\"" + key + "\" : \"" + payloads + "\"}")
            if key == "payload":
                payloads = payload[key]
            if key == "url":
                url = payload[key]
            else:
                pass

        print(method + "\n" + str(headers) + url + payloads)
        response = requests.post(url=url, headers=headers, data=payloads)
        self.wfile.write(response.content)
        self.wfile.write((str(response.headers)).encode())
    def do_PUT(self):
        self.send_response(404)



# Запускаем HTTP сервер на порту 8081
server = HTTPServer(('0.0.0.0', 8081), ServiceHandler)
server.serve_forever()
